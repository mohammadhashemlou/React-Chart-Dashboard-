```
npm install

npm start

```
